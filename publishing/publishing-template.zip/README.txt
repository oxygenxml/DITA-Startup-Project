A sample publishing template for 'flowers' DITA map. 
You can use it as a starting point to create a new publishing template. 